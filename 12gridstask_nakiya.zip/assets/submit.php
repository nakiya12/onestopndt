<?php
// Define variables to store error messages
$nameError = $emailError = "";
$formSubmitted = false;
$errors = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty($_POST["name"])) {
        $nameError = "Name is required.";
        $errors = true;
    } else {
        $name = htmlspecialchars($_POST["name"]);
    }

    // Validate email
    if (empty($_POST["email"])) {
        $emailError = "Email is required.";
        $errors = true;
    } elseif (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $emailError = "Invalid email format.";
        $errors = true;
    } else {
        $email = htmlspecialchars($_POST["email"]);
    }

    // Check if there are errors before submitting
    if (!$errors) {
        // Code to handle form submission, like saving data or sending an email
        $formSubmitted = true;
    }
}
?>
