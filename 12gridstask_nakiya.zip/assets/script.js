document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting for demonstration

    const successMessage = document.createElement('p');
    successMessage.textContent = "Form submitted successfully!";
    successMessage.style.color = 'green';
    document.querySelector('form').appendChild(successMessage);

    setTimeout(() => successMessage.remove(), 5000); // Remove after 5 seconds
});
