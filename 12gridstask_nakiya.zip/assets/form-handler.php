<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $organization = htmlspecialchars($_POST['organization']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);

    // Handle form data (e.g., save to database or send email)
    echo "Thank you, $name! Your submission has been received.";
} else {
    echo "Invalid form submission.";
}
?>
